Tools and Technology: 
Front End: HTML, CSS, Bootstrap, JavaScript, XML
Back End: Php, MySQL
IDE: Visual Studio Code
Server: XAMPP

Steps:
Transfer user folder into htdocs of local system xampp folder.
Create Database 'user' and export user.sql file from the user folder.
Run login.php using localhost.